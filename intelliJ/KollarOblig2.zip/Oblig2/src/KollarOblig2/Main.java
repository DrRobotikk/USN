package KollarOblig2;

public class Main {
    //Funksjon som starter hele programmet
    public static void main(String[] args) {
        Grensesnitt programStart = new Grensesnitt();

        programStart.start();
    }
}
